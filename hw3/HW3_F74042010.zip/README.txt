1.file name:
  hw3_1.pl  
  hw3_2.pl
  hw3_3.pl

2.How to run:

  $ swipl -q -s xxx.pl

  then   
  main .

in hw3_1:(can repeat)
  main.
  xxx(a even number bigger than 2 you want to input)

in hw3_2:(one time only)
  main.
  then screen show input:\n
  then tap the input 
  after input screen will show query:\n
  then tap the query input to know the answer(1 input show 1 answer)

in hw3_3:(one time only)
  nearly the same as hw3_2


p.s. ALL above input don't need to tap '.'

3.
thank you for pay attention to this README ^^

